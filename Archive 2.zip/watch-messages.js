const { PubkyCLIAuth } = require('./pubky-cli-auth');
const axios = require('axios');
const pubkyAppSpecs = require('pubky-app-specs');
const { PubkySpecsBuilder } = pubkyAppSpecs;
const fs = require('fs');
const path = require('path');

const auth = new PubkyCLIAuth();

auth.on('login', async (data) => {
        const wasmPath = path.join(__dirname, 'node_modules', 'pubky-app-specs', 'pubky_app_specs_bg.wasm');
        const wasmBuffer = fs.readFileSync(wasmPath);
        await pubkyAppSpecs.default(wasmBuffer); // Initialize WASM module
        const userPublicKeyString = data.remotePeer.z32();
        const specs = new PubkySpecsBuilder(userPublicKeyString);
        console.log('Connected to client!');
        console.log(`User public key: ${userPublicKeyString}`);

        let knownPostUris = new Set();

        const checkForNewPosts = async () => {
            try {
                const url = `pubky://${userPublicKeyString}/pub/pubky.app/posts/`;
                const response = await data.client.fetch(url);
                if (!response.ok) {
                    console.error(`Failed to fetch posts list: ${response.statusText}`);
                    return;
                }

                const text = await response.text();
                const postUris = text.trim().split('\n').filter(uri => uri);

                let newUris = [];
                if (knownPostUris.size === 0) {
                    // First run, all are known
                    postUris.forEach(uri => knownPostUris.add(uri));
                    console.log(`Initialized with ${knownPostUris.size} existing posts. Waiting for new ones...`);
                } else {
                    newUris = postUris.filter(uri => !knownPostUris.has(uri));
                }

                if (newUris.length > 0) {
                    console.log(`Found ${newUris.length} new post(s):`);
                    newUris.forEach(uri => knownPostUris.add(uri)); // Add to known URIs immediately

                    for (const uri of newUris) {
                        try {
                            const postResponse = await data.client.fetch(uri);
                            if (postResponse.ok) {
                                const post = await postResponse.json();
                                console.log('------------------------');
                                console.log(`New Post at ${uri}:
`, JSON.stringify(post, null, 2));
                                console.log('------------------------');

                                if (post.content) {
                                    const tags = await getTagsFromOllama(post.content);
                                    if (tags && tags.length > 0) {
                                        await applyTags(uri, tags, specs, data.client);
                                    }
                                }
                            } else {
                                console.error(` - Failed to fetch content for ${uri}: ${postResponse.statusText}`);
                            }
                        } catch (e) {
                            console.error(` - Error processing post ${uri}:`, e.message);
                        }
                    }
                }

            } catch (error) {
                console.error('Error checking for new posts:', error.message);
            }
        };

        // Check for new posts every 10 seconds
        console.log('Watching for new posts...');
        setInterval(checkForNewPosts, 10000);
        // Initial check
        await checkForNewPosts();
    });

async function getTagsFromOllama(content) {
    console.log('Sending content to Ollama to find tags...');
    try {
        const response = await axios.post('http://localhost:11434/api/generate', {
            model: 'mistral:latest',
            prompt: `Extract 3 relevant tags from the following text. Respond with a comma-separated list of single words. Text: "${content}"`,
            stream: true
        }, { responseType: 'stream' });

        let ollamaResponse = '';
        for await (const chunk of response.data) {
            const chunkStr = chunk.toString();
            try {
                const json = JSON.parse(chunkStr);
                ollamaResponse += json.response;
                process.stdout.write(json.response);
            } catch (e) {
                // Not a valid JSON, maybe just a string chunk
            }
        }
        console.log('\nOllama stream finished.');
        return ollamaResponse.split(',').map(tag => tag.trim()).filter(tag => tag);
    } catch (error) {
        console.error('Error getting tags from Ollama:', error.message);
        return [];
    }
}

async function applyTags(postUri, tags, specs, client) {
    console.log(`Applying tags: ${tags.join(', ')}`);
    for (const tag of tags) {
        const tagLabel = tag.trim();
        if (!tagLabel) continue;

        try {
            const result = specs.createTag(postUri, tagLabel);

            console.log('Result of createTag:', result);
            console.log(' - tag:', result.tag);
            console.log(' - meta:', result.meta);
            console.log(' - meta keys:', Object.keys(result.meta));
            if(result.meta.url) {
                console.log(' - meta.url type:', typeof result.meta.url);
                console.log(' - meta.url value:', result.meta.url);
            }

            const body = JSON.stringify(result.tag.toJson());

            console.log('✅  Serialized Tag JSON:', body);

            const headers = new Headers();
            headers.append('Content-Type', 'application/json');

            const response = await client.fetch(result.meta.url, {
                method: 'PUT',
                body: new TextEncoder().encode(body),
                headers,
                credentials: 'include'
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP error! status: ${response.status}, ${errorText}`);
            }

            console.log(`✅ Successfully applied tag: ${tagLabel}`);

        } catch (error) {
            console.error(`❌ Error applying tag "${tagLabel}":`, error.message);
        }
    }
}

console.log('🚀 Démarrage de la surveillance des messages...');
auth.login();